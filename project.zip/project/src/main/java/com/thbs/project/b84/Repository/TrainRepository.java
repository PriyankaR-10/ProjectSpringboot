package com.thbs.project.b84.Repository;


import com.thbs.project.b84.Model.trains;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TrainRepository extends CrudRepository<trains, Integer>{
}
