package com.thbs.project.b84.Controller;

import com.thbs.project.b84.Model.Passenger;
import com.thbs.project.b84.Model.Ticket;
import com.thbs.project.b84.Model.trains;
import com.thbs.project.b84.Model.User;
import com.thbs.project.b84.Repository.PassengerRepo;
import com.thbs.project.b84.Repository.TrainRepository;
import com.thbs.project.b84.Repository.UserRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;

@Controller
public class TrainController {
	
	@Autowired
	TrainRepository trainRepository;
	@Autowired
	Ticket ticket;
	@Autowired
	UserRepo userRepo;
	@Autowired
	PassengerRepo passengerRepo;

	@RequestMapping("type")
	public String admin(HttpServletRequest request)
	{
		if(request.getParameter("value").equals("admin")){
			return "admin.jsp";
		}
		else
		{
			return "Login.jsp";
		}
	}

	@RequestMapping("adminop")
	public String adminop(HttpServletRequest request,trains train)
	{
		switch (request.getParameter("value"))
		{
			case "Add":
				trainRepository.save(train);
				break;
			case "Modify":
				trainRepository.save(train);
				break;
			case "Delete":
				trainRepository.delete(train);
				break;
		}
		return "adminoperations.html";
	}

	@RequestMapping("userop")
	public String userop(HttpServletRequest request, User users)
	{
		switch (request.getParameter("value"))
		{
			case "Save":
				userRepo.save(users);
				break;
			case "Delete Account":
				userRepo.delete(users);
				break;
		}
		return "passenger.html";
	}


	@RequestMapping("login")
	public String Login(HttpServletRequest request,User user)
	{
		System.out.println("success");
		return "passenger.html";
	}

	@RequestMapping("passdetails")
	public String login(HttpServletRequest request, @RequestParam int noOfPassengers, Passenger pass)
	{
		System.out.println("success");
		for(int i=1;i<=noOfPassengers;i++)
		{
			String name=request.getParameter("name"+i);
			int age=Integer.parseInt(request.getParameter("age"+i));
			char gender=request.getParameter("gender"+i).charAt(0);
			//ticket.addPassengers(name,age,gender);
		}
		return "payment.html";
	}


}
