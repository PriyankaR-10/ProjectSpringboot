package com.thbs.project.b84.Repository;

import com.thbs.project.b84.Model.Passenger;
import org.springframework.data.repository.CrudRepository;

public interface PassengerRepo extends CrudRepository<Passenger, Integer> {
}
